package domain; 

public class HelloWorld { public static void main(String[] args) { 
    
    double A = 1 - 0.10;
    double B = 1 - 0.15;
    double C = 1 - 0.20;
    double D = 1 + 0.05;
    double valor = 60.00;
    double classf = D;

    if(classf ==Aclassf ==Bclassf ==C){ 
        double descontof = valorclassf;
        double desconto = valor-descontof;
        
        System.out.println("Valor: "+valor);
        System.out.println("Valor final: "+descontof);
        System.out.println("Desconto: "+desconto);
        
        } else{
            double acrescimof = valorclassf;
            double acrescimo = acrescimof-valor;
            
            System.out.println("Valor: "+valor);
            System.out.println("Valor final: "+acrescimof);
            System.out.println("Acréscimo: "+acrescimo); 
            
        } 
        
    }
}