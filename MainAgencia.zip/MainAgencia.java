package sample;
import sample.model.Funcionario;
import sample.model.Clientefc;
import sample.model.Pessoafc;

public class MainAgencia {
    public static void main(String[] args) {
        Funcionario funcionario= new Funcionario("Matheus","Médico","15.000R$");
        funcionario.setSobrenome("Cabral");
        funcionario.setEmail("matheus.cabral2019@hotmail.com");
        funcionario.setTelefone("48998218211");
        System.out.println(funcionario);

        Funcionario funcionario2= new Funcionario("Volineor","Lixeiro","U$10.000");
        funcionario2.setSobrenome("Plinio");
        funcionario2.setEmail("Volineor.plinio2000@gmail.com");
        funcionario2.setTelefone("48998826660");
        System.out.println(funcionario2);


    }



}

