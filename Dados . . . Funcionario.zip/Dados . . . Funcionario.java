

package sample;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        Triangulo x = new Triangulo();
        x.a = 3.0D;
        x.b = 4.0D;
        x.c = 5.0D;
        Triangulo y = new Triangulo();
        y.a = 7.5D;
        y.b = 4.5D;
        y.c = 4.02D;
        double areaX = x.Area();
        double areaY = y.Area();
        System.out.pri
                        a


package sample;

import java.util.Scanner;
import sample.model.EXE1;

public class MainEXE1 {
    public MainEXE1() {
    }

    public static void main(String[] args) {
        Scanner leitura = new Scanner(System.in);
        EXE1 e = new EXE1(leonardo);
        EXE1 e2 = new EXE1(17);
        System.out.println("coloque o nome da primeira pessoa: ");
        e.nome = leitura.nextLine();
        Syst
                                  a

package sample;

import java.util.Scanner;
import sample.model.EXE2;

public class MainEXE2 {
    public MainEXE2() {
    }

    public static void main(String[] args) {
        Scanner leitura = new Scanner(System.in);
        EXE2 e = new EXE2(jalmir);
        EXE2 e2 = new EXE2(5000);
        System.out.println("Nome do primeiro funcionário: ");
        e.nome = leitura.nextLine();
        System.o
                                            a


package sample;

import java.util.Scanner;
import sample.model.Produto;

public class MainProduto {
    public MainProduto() {
    }

    public static void main(String[] args) {
        Scanner leitura = new Scanner(System.in);
        Produto produto = new Produto(cimento);
        System.out.println("Entre com os dados do produto");
        System.out.println("Nome:");
        produto.Nome = lei
                                   a



package sample;

public class Triangulo {
    public double a;
    public double b;
    public double c;

    public Triangulo() {
    }

    public double Area() {
        double p = (this.a + this.b + this.c) / 2.0D;
        double area = Math.sqrt(p * (p - this.a) * (p - this.b) * (p - this.c));
        return area;
    }
}