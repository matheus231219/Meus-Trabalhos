package domain;

public class HelloWorld {

    public static void main(String[] args) {
        class conta {//classe conta

    //declarar os atributos da classe conta
    double numero, numeroconta, saldo;

    //métedo depositar
    void depositar(double valor){
         this.saldo = this.saldo + valor;
    }

    //método sacar
    double sacar(double valorParaSacar){

        if (valorParaSacar <= this.saldo){//se tiver saldo, pode sacar
            this.saldo = this.saldo -valorParaSacar;
            return valorParaSacar;
            } else {
            return 0; //não tem saldo para sacar
        }

    }
}
    }

}
