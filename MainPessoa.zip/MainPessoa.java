package sample;

import sample.model.Pessoa;

import java.security.spec.RSAOtherPrimeInfo;

public class MainPessoa {

    public static void main(String[] args)

    {
        Pessoa pessoa = new Pessoa();

        pessoa.setNome("Matheus");
        System.out.println("Nome : "+pessoa.getNome());
        pessoa.setDataNascimento("15/12/2003");
        System.out.println("Data de Nascimento : "+ pessoa.getDataNascimento());

        System.out.println("\n\n");

        Pessoa pessoa2 = new Pessoa();

        pessoa2.setNome("Volineonor");
        System.out.println("Nome : "+pessoa2.getNome());
        pessoa2.setDataNascimento("25/11/2000");
        System.out.println("Data de Nascimento : "+ pessoa2.getDataNascimento());

    }


}


